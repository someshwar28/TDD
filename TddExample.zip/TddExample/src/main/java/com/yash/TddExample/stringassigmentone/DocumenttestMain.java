package com.yash.TddExample.stringassigmentone;

public class DocumenttestMain {
	public static void main(String[] args) {
		documentmain dc=new documentmain();
		
		System.out.println(dc.showDocumentInformation());
	}

}
