package com.yash.TddExample.stringassignmentfour;

public class CategoryMain {
public static void main(String[] args) {
	Category c =new Category();
	
	String cdetail=c.showCategoryDetail();
	System.out.println(cdetail);
	
}
}
